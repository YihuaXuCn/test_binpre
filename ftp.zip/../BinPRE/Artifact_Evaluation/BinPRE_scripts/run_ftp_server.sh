


cd ../../src

echo '  [!!!!!!!!!!!!!!!!!!!!]Users (reviewers), please note that a letter 'e' needs to be entered here in order to switch modes.'
./run run taint ./ftp/fftp ./ftp/fftp.conf
