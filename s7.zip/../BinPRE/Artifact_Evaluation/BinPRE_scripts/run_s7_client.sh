

cd ../../Analyzer

python3 fsend_split.py s7 0 0 oa index big 0
#wait and enter threadId: 1
#Total Analyze Time:416.99148750305176
